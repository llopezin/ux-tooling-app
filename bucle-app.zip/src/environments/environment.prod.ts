export const environment = {
  production: true,
  apiUrl: 'https://bucle-app.herokuapp.com/api'
};
