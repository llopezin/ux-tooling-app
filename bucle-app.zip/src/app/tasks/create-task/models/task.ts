export interface Task {
    _id?: string,
    name: string,
    type: string,
    questions?: string[] 
}