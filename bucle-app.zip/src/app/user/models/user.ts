export interface User {
  email: string;
  campaigns: string[];
  Dashboard_id: string
}
